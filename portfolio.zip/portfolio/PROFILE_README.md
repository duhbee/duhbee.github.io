### Hi, I'm Trisha 👋

I write the lighting, shadows and tools that make real-time games and simulations work, mostly in C and C++. I'm a third-year Computer Science student in Real-Time Interactive Simulation at the Singapore Institute of Technology (SIT) and DigiPen.

**Portfolio:** [duhbee.github.io](https://duhbee.github.io)

**Selected projects**
- **The Last Act**: technical lead and graphics on an 8-person 2D puzzle-platformer in our own C++ and OpenGL engine. I built the spotlight and shadow system and the editor's lighting tools. [Gameplay video](https://www.youtube.com/watch?v=wYaBSyx7Sx4)
- **DDS Light Cycles**: real-time multiplayer game in C, with networking over Cyclone DDS (Data Distribution Service). I built the OpenGL client.
- **VArchive**: web platform for 3D cultural heritage records, built with React, TypeScript and Three.js by a 12-person team.

School project code is private, so I'm happy to walk through it on a call.

**Looking for** an internship in game programming, graphics, simulation or C++ software engineering from May 2027 to April 2028.

📫 trishaa1302@gmail.com

💼 [LinkedIn](https://www.linkedin.com/in/trishatan-chenqiaoting)
